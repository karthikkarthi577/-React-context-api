import React from 'react'
import Users from './Users';

const App = () => {

  
  return (
    <div>
      {/* consumer component */}
      <Users />
    
    </div>
  )
}

export default App